Data set:
	EBT 
Description: 
	Event Based Traceability
Artifacts:
	40 Requirements
	50 Java Source code classes
	25 Test cases
	Trace links from requirements to classes 
	Trace links from requirements to test cases

Data source: 
	Jane Cleland-Huang, Carl K. Chang, Mark J. Christensen:
	Event-Based Traceability for Managing Evolutionary Change. IEEE Trans. Software Eng. 29(9): 796-810 (2003)