Data is provided courtesy of NASA collated by Jane Huffman Hayes.
Please reference the following paper if you use this dataset:

Jane Huffman Hayes, Alex Dekhtyar, Senthil Karthikeyan Sundaram:
Advancing Candidate Link Generation for Requirements Tracing: The Study of Methods. IEEE Trans. Software Eng. 32(1): 4-19 (2006)

@article{DBLP:journals/tse/HayesDS06,
  author    = {Jane Huffman Hayes and
               Alex Dekhtyar and
               Senthil Karthikeyan Sundaram},
  title     = {Advancing Candidate Link Generation for Requirements Tracing: The
               Study of Methods},
  journal   = {{IEEE} Trans. Software Eng.},
  volume    = {32},
  number    = {1},
  pages     = {4--19},
  year      = {2006},
  url       = {http://dx.doi.org/10.1109/TSE.2006.3},
  doi       = {10.1109/TSE.2006.3},
  timestamp = {Thu, 10 Dec 2015 11:33:20 +0100},
  biburl    = {http://dblp.uni-trier.de/rec/bib/journals/tse/HayesDS06},
  bibsource = {dblp computer science bibliography, http://dblp.org}
}


