Data set:
	eAnci
Description: 
	Italian municipalities management system
Source: 
	Use cases
Target: 
	Classes

Directory structure
	source_req.xml: source artifacts file (140 artifacts)
	target_code.xml: target artifacts file (55 artifacts)
	answer_req_code.xml: answer matrix file (567 links)
	uc: directory that contains actual source artifacts
	cc: directory that contains actual target artifacts

Data source: 
	M. Gethers, R. Oliveto, D. Poshyvanyk, and A. D.Lucia. 
	On integrating orthogonal information retrieval methods to improve traceability recovery. 
	In Proc. of Intn��l Conf. on Software Maintenance, 2011.