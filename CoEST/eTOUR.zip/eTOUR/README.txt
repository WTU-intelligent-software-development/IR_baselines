Data set:
	eTour
Description: 
	Tour guide system
Source: 
	Use Cases 
Target: 
	Classes

Directory structure
	source_req.xml: source artifacts file (58 artifacts)
	target_code.xml: target artifacts file (116 artifacts)
	answer_req_code.xml: answer matrix file (308 links)
	UC: directory that contains actual source artifacts
	CC: directory that contains actual target artifacts
	

Data source: 
	TEFSE challenge, The 6th Internation Workshp on Traceability in Emerging Forms of Software Engineering, 
	http://www.cs.wm.edu/semeru/tefse2011/challenge.htm, 2011.